import qrcode
img = qrcode.make("I love Mustang more than anything!!")
img.save("mustangQr.jpg")
