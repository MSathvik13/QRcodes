import cv2
d = cv2.QRCodeDetector()
path = r'C:\Python Programs\Projects\QRcode\mustangQr.jpg'
val, _, _ = d.detectAndDecode(cv2.imread(path))
print("Decoded text is: ", val)

# Displaying a QRcode using 'imread()'

img = cv2.imread(path)
cv2.imshow('image', img)
